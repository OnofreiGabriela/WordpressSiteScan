<?php 
	include('../config.php');
	header('Content-Type: text/javascript');
?>
var wplc_api_server = '<?php echo WLPC_UPDATE_SERVER; ?>';